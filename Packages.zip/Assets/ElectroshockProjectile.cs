using UnityEngine;

public class ElectroshockProjectile : MonoBehaviour
{
    public float speed = 15f;
    public int damage = 1;
    public float lifetime = 2f;

    private Vector2 moveDirection;
    private SpriteRenderer sr;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        if (sr != null)
        {
            sr.sortingOrder = 30; 
            sr.color = Color.white; 
        }
        else
        {
            Debug.LogError("¡Este prefab de proyectil NO tiene Sprite Renderer!");
        }

        Destroy(gameObject, lifetime);
    }

    public void SetDirection(Vector2 direction)
    {
        moveDirection = direction.normalized;
    }

    void Update()
    {
        transform.Translate(moveDirection * speed * Time.deltaTime, Space.World);
    }
    
    private void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("Player"))
        {
            return; 
        }

        Debug.Log(gameObject.name + " [PROYECTIL] Collided with: " + other.name + " (Tag: " + other.tag + ")");

        if (other.CompareTag("Enemy"))
        {
            Debug.Log(gameObject.name + " [PROYECTIL] Hit confirmed as ENEMY.");
            
            EnemyHealth enemy = other.GetComponent<EnemyHealth>();
            if (enemy != null)
            {
                Debug.Log(gameObject.name + " [PROYECTIL] Found EnemyHealth script on " + other.name + ". Calling TakeDamage(" + damage + ")");
                enemy.TakeDamage(damage);
            }
            else
            {
                Debug.LogWarning(gameObject.name + " [PROYECTIL] Hit ENEMY, but no EnemyHealth script was found on " + other.name);
            }
        }

        Debug.Log(gameObject.name + " [PROYECTIL] Destroying self after collision.");
        Destroy(gameObject);
    }
}

