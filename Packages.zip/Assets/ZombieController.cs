using UnityEngine;

public class ZombieController : MonoBehaviour
{
    protected Rigidbody2D rb;
    public Animator anim;
    public Transform spriteTransform;
    
    [Header("Configuración General")]
    public float moveSpeed = 2f;
    public int maxHealth = 3;
    protected int currentHealth;
    public LayerMask playerLayer;
    public GameObject deathEffectPrefab;
    
    [Header("Detección")]
    public Vector2 detectionBoxSize = new Vector2(5f, 2f);
    public Vector2 attackBoxSize = new Vector2(1f, 1f);
    public Transform playerCheck;
    public Transform groundDetection;
    public float groundCheckDistance = 0.5f;
    public LayerMask groundLayer;
    
    [Header("Ataque")]
    public float attackCooldown = 1.5f;
    protected float lastAttackTime;
    
    protected bool movingRight = true;
    protected Transform player;
    protected bool isAttacking = false;
    protected bool isDying = false;
    protected bool isTakingHit = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        currentHealth = maxHealth;

        if (spriteTransform == null)
            Debug.LogError("¡ERROR! 'Sprite Transform' NO está asignado en " + gameObject.name);
        
        if (anim == null)
            Debug.LogWarning("Advertencia: 'Anim' (Animator) no está asignada en " + gameObject.name);
        
        if (playerCheck == null)
            Debug.LogError("¡ERROR! 'Player Check' NO está asignado en " + gameObject.name);
            
        if (groundDetection == null)
            Debug.LogError("¡ERROR! 'Ground Detection' NO está asignado en " + gameObject.name);
    }

    void Update()
    {
        if (isDying || isTakingHit) return;

        FindPlayer(); 

        if (player != null)
        {
            float distanceToPlayer = Vector2.Distance(playerCheck.position, player.position);

            if (distanceToPlayer <= attackBoxSize.x / 1.5f) 
            {
                AttackPlayer();
            }
            else if (distanceToPlayer <= detectionBoxSize.x / 1.5f)
            {
                ChasePlayer();
            }
            else
            {
                Patrol();
            }
        }
        else
        {
            Patrol();
        }

        if(anim != null)
        {
            anim.SetBool("isAttacking", isAttacking);
            anim.SetFloat("speed", Mathf.Abs(rb.linearVelocity.x));
        }
    }

    protected virtual void FindPlayer()
    {
        if (playerCheck == null)
        {
            return; 
        }
        
        if (player == null)
        {
            Collider2D playerCollider = Physics2D.OverlapBox(playerCheck.position, detectionBoxSize, 0, playerLayer);
            if (playerCollider != null)
            {
                player = playerCollider.transform;
            }
        }
        else
        {
            if (!player.gameObject.activeSelf || Vector2.Distance(playerCheck.position, player.position) > (detectionBoxSize.x * 1.5f))
            {
                player = null;
            }
        }
    }

    protected virtual void Patrol()
    {
        isAttacking = false;
        
        if (groundDetection == null) return;

        RaycastHit2D groundInfo = Physics2D.Raycast(groundDetection.position, Vector2.down, groundCheckDistance, groundLayer);

        if (groundInfo.collider == null) 
        {
            if (isGrounded()) 
            {
                movingRight = !movingRight;
                Flip();
            }
        }

        rb.linearVelocity = new Vector2(movingRight ? moveSpeed : -moveSpeed, rb.linearVelocity.y);
    }
    
    protected virtual void OnCollisionEnter2D(Collision2D collision)
    {
        if (isDying || isTakingHit || collision.gameObject.CompareTag("Player"))
        {
            return;
        }

        if (collision.contacts.Length > 0)
        {
            float normalX = collision.contacts[0].normal.x;

            if (Mathf.Abs(normalX) > 0.5f)
            {
                if (normalX < 0 && movingRight)
                {
                    movingRight = false;
                    Flip();
                }
                else if (normalX > 0 && !movingRight)
                {
                    movingRight = true;
                    Flip();
                }
            }
        }
    }

    protected virtual void ChasePlayer()
    {
        isAttacking = false;
        
        if (player == null) return;

        float direction = Mathf.Sign(player.position.x - transform.position.x);
        rb.linearVelocity = new Vector2(direction * moveSpeed * 1.2f, rb.linearVelocity.y); 

        if (direction > 0 && !movingRight)
        {
            movingRight = true;
            Flip();
        }
        else if (direction < 0 && movingRight)
        {
            movingRight = false;
            Flip();
        }
    }

    protected virtual void AttackPlayer()
    {
        isAttacking = true;
        rb.linearVelocity = Vector2.zero; 

        if (player != null)
        {
            float direction = Mathf.Sign(player.position.x - transform.position.x);
            if (direction > 0 && !movingRight)
            {
                movingRight = true;
                Flip();
            }
            else if (direction < 0 && movingRight)
            {
                movingRight = false;
                Flip();
            }
        }

        if (Time.time >= lastAttackTime + attackCooldown)
        {
            if(anim != null) anim.SetTrigger("attack"); 

            if (playerCheck == null) return;

            Collider2D playerHit = Physics2D.OverlapBox(playerCheck.position, attackBoxSize, 0, playerLayer);
            if (playerHit != null)
            {
                kaiAnimation playerHealth = playerHit.GetComponent<kaiAnimation>();
                if (playerHealth != null)
                {
                    playerHealth.LoseLife();
                }
            }
            lastAttackTime = Time.time;
        }
    }
    
    protected void Flip()
    {
        if (spriteTransform == null)
        {
            Debug.LogError("¡ERROR DE FLIP! 'Sprite Transform' está 'null'.", this.gameObject);
            return;
        }
        
        Vector3 scaler = spriteTransform.localScale;
        scaler.x *= 1;
        spriteTransform.localScale = scaler;
    }
    
    protected bool isGrounded()
    {
        if (groundDetection == null) return false;
        RaycastHit2D groundInfo = Physics2D.Raycast(groundDetection.position, Vector2.down, groundCheckDistance, groundLayer);
        return groundInfo.collider != null;
    }

    public void TakeDamage(int damage)
    {
        if (isDying || isTakingHit) return;

        currentHealth -= damage;
        isTakingHit = true; 
        rb.linearVelocity = Vector2.zero;
        
        if(anim != null) anim.SetTrigger("hit"); 
        
        if (currentHealth <= 0)
        {
            Die();
        }
    }
    
    public void OnHitAnimationComplete()
    {
        isTakingHit = false;
    }

    protected void Die()
    {
        isDying = true;
        if(anim != null) anim.SetTrigger("die"); 
        rb.linearVelocity = Vector2.zero;
        GetComponent<Collider2D>().enabled = false; 
        this.enabled = false; 
        
        if (deathEffectPrefab != null)
        {
            Instantiate(deathEffectPrefab, transform.position, Quaternion.identity);
        }
        
        Destroy(gameObject, 2f);
    }

    protected virtual void OnDrawGizmosSelected()
    {
        if (playerCheck != null)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireCube(playerCheck.position, detectionBoxSize);
            Gizmos.color = Color.red;
            Gizmos.DrawWireCube(playerCheck.position, attackBoxSize);
        }

        if (groundDetection != null)
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawLine(groundDetection.position, groundDetection.position + Vector3.down * groundCheckDistance);
        }
    }
}